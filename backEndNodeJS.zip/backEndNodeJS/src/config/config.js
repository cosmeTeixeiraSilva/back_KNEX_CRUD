import dotenv from 'dotenv';
// Carrega variáveis de ambiente do arquivo .env para process.env
dotenv.config();

