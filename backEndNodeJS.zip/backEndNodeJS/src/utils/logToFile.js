import fs from 'fs';
import path, { dirname } from 'path';
import { format } from 'date-fns'; // Importa a função de formatação
// Defina o caminho do arquivo de log
const logFilePath = path.resolve(process.cwd(), 'logs', 'logs.log');

// Função para formatar a data no formato brasileiro
function formatBrazilianDate(date) {
  return format(date, 'dd/MM/yyyy HH:mm:ss');
}
// Função para gravar logs
export function logToFile(message) {

  // Cria o diretório de logs se não existir
  fs.mkdir(path.dirname(logFilePath), { recursive: true }, (err) => {
    if (err) {
      console.error('Falha ao Criar o Log:', err);
    }
  });

  // Adiciona a mensagem ao arquivo de log \n pula linha no appendFile observação apenas caso precise usar
  fs.appendFile(logFilePath, `\n${formatBrazilianDate(new Date())} - ${message}`, (err) => {
    if (err) {
      console.error(`Falha ao escrever o Log no Arquivo: ${logFilePath}`, err);
      console.error(`Log que seria Gravado : ${formatBrazilianDate(new Date())} - ${message}\n}`, err);
    }
  });
}

