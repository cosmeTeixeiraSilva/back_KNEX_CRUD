import bcrypt from 'bcrypt'
export async function  hashSenha(senha) {
    //Quanto maior for mais díficil de quebrar sua senha porem o processo mais demorado 
    const saltRounds = 10;
    const hashedPassWord = await bcrypt.hash(senha, saltRounds)
    console.log(`Senha Normal: ${senha}`)
    console.log(`Senha Criptografada: ${hashedPassWord}`)
    return hashedPassWord

}