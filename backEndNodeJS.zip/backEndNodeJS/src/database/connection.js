// src/db/connection.js
import knex from 'knex';
import path from 'path';
import knexfile from './knexfile.js';

import { logToFile } from '../utils/logToFile.js';
import dotenv from 'dotenv';
import { isExists } from 'date-fns';
// Carrega variáveis de ambiente do arquivo .env para process.env
dotenv.config({
    path: path.resolve(process.cwd(), '../../', '.env') // Define o caminho para o arquivo .env

});
//escolhendo o ambiente de Trabalho Desenvolvimento ou Produção
console.log(process.cwd())
const environment = process.env.DB_ENV || 'sqlite';
if (process.env.DB_ENV == undefined) {
    console.log('Favor Verificar o caminho do .env - Arquivo de Configurações ')
}
console.log(`Ambiente de Trabalho: ${environment}`)
//pegando as Configurações
const config = knexfile[environment];
//instanciando o Objeto de acordo com o banco escolhido no .env
const db = knex(config);
//Gravando um log de Instruções SQL 
db.on('query', (query) => {
    console.log('SQL Query:', query.sql);
    const sql = `SQL Query: ${query.sql}`;
    const bindings = query.bindings.length ? `${query.bindings}` : '';
    const message = bindings ? `${sql} - Paramentros da SQL (Bindings): ${bindings}` : sql;
    // Chamando a função de Gravar a consulta SQL no arquivo de logs/logs.log
    logToFile(message);
    if (query.bindings.length) {
        console.log('Bindings:', query.bindings)
    }
});
//Exportando para Uso
export default db;