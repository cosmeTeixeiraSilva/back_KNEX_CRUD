// knexfile.js
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import path from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
export default {

    sqlite: {
        client: 'sqlite3',
        connection: {
            filename: path.resolve(__dirname, 'banco.sqlite')
        },
        useNullAsDefault: true,
        migrations: {
            directory: path.resolve(__dirname, 'migrations')
        }
    },
    pgSQL: {
        // Configurações para produção com PostgreSQL 
        client: 'pg',
        connection: {

            host: '127.0.0.1',
            port: '5432',
            user: 'postgres',
            database: 'competicao',
            password: 'root',
            ssl: process.env.DB_SSL ? { rejectUnauthorized: false } : false,
        },
    },
    mySQL: {
        // Configurações para produção com MYSQL
        client: 'mysql2',
        connection: {
            host: '127.0.0.1',
            port: '3306',
            user: 'root',
            password: 'root',
            database: 'competicoes',
        },
    }
};
