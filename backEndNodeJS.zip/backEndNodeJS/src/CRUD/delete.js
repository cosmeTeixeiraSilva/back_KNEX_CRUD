import database from "../database/connection.js";
//montar a QUERY SQL com  a proteção catch caso erro aconteça
//posso escolher os campos no SELECT -> db.select(["id","nome"])
database.where({ id: 6 }).delete().table('users').debug().then(data => {
    //ver a QUERY Montada no console para Debugar a Instrução SQL 
    console.log(`Usuário Deletado com Sucesso.... ${data}`)
}).catch(err => {
    console.log(err);
});

