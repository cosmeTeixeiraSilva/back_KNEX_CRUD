import db from "../database/connection.js";
import bcrypt from 'bcrypt'

//passar um JSON (CHAVE: valor para cada campo) 
/* var usuario = {
    nome: "Zeus Teixeira Silva",
    celular: "(35) 98888 - 0000",
    email: "zeus@email.com",
    ativo: 1

} */
//ou um Array de Usuarios 
var usuarios = [
    {
        nome: "Usuário 90",
        celular: "(35) 98888 - 0000",
        email: "usuario90@email.com",
        ativo: 1,
        senhaCrypto: await bcrypt.hash('123', 10)

    },
    {
        nome: "Usuário 91",
        celular: "(35) 98888 - 0000",
        email: "usuario91@email.com",
        ativo: 0,
        senhaCrypto: await bcrypt.hash('333', 10)

    },
    {
        nome: "Usuário 92",
        celular: "(35) 98888 - 0000",
        email: "usuario92@email.com",
        ativo: 0,
        senhaCrypto: await bcrypt.hash('458', 10)

    }
]
//OBS: Usando o KNEX qdo for um ARRAY com 100 registros não necessita de um FOR, ou FOREACH ou qualquer laço de repetição 
//mostrar o JSON 
//onsole.log(usuarios);
//uso do BCRYPT para senhas 
// Define o número de salt rounds (quanto maior o número, mais seguro, mas mais lento)
//montar a QUERY SQL com  a proteção catch caso erro aconteça
const database = db.insert(usuarios).into("users").debug().then(data => {
    //ver a QUERY Montada no console para Debugar a Instrução SQL 

    console.log(data);
}).catch(err => {
    console.log(err);
});




