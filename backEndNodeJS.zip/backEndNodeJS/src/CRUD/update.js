import database from "../database/connection.js";
const NovoAtivo = 1;
const NovoEmail = 'matheus@email.com';
const NovoCelular = "9999999999";
const id_User = 3;  //ID a ser Atualizado pode ser pego via bodyParser com JSON nos Formulários
//Todos os Campos que deseja atualizar será colocado dentro do metodo UPDATE no formato JSON 
database.select().where({ id: id_User }).update({ ativo: NovoAtivo, email: NovoEmail, nome: "Matheus",celular: NovoCelular}).table('users').debug().then(data => {

    console.log(`Quantidade Registros Afetados: ${data}`);
}).catch(err => {
    console.log(err);
});

