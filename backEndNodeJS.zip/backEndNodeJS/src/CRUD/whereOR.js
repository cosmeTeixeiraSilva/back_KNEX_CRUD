import db from "../database/connection.js";


//montar a QUERY SQL com  a proteção catch caso erro aconteça
//posso escolher os campos no SELECT -> db.select(["id","nome"])
const database = db.select().where({ativo: 0}).table('users').debug().then(data => {
    //ver a QUERY Montada no console para Debugar a Instrução SQL 
    console.log(data);
    console.log(`Quantidade de Usuários Inativos (ativo = 0): ${data.length}`)
}).catch(err => {
    console.log(err);
});

//ou com AND 
const database2 = db.select()
                  .where({ativo: 0})
                  .orWhere({cidade: 'lavras'})
                  .table('users')
                  .debug()
                  .then(data => {
    //ver a QUERY Montada no console para Debugar a Instrução SQL 
    console.log(data);
    console.log(`Quantidade de Usuários Inativos (ativo = 0): ${data.length}`)
}).catch(err => {
    console.log(err);
});



