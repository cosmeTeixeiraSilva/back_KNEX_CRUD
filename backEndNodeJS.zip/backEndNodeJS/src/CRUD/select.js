import database from "../database/connection.js";
//montar a QUERY SQL com  a proteção catch caso erro aconteça
//posso escolher os campos no SELECT -> db.select(["id","nome"])
database.select(["id", "nome", "email", "ativo"]).table('users').orderBy("nome", "asc").debug().then(data => {
    //ver a QUERY Montada no console para Debugar a Instrução SQL 
    console.log(data);
    console.log(`Quantidade de Registros na Tabela selecionada: ${data.length}`)
}).catch(err => {
    console.log(err);
});




